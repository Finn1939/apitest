import "dotenv/config";
import { Client, Events, GatewayIntentBits, Options, Partials } from "discord.js";
import { config, validateConfig } from "./config.js";
import { parseCommand } from "./commands.js";
import { askAI } from "./ai.js";
import { searchWeb } from "./search.js";
import {
  HISTORY_LIMIT,
  addFact,
  addHistory,
  loadMemory,
  parseRememberCommand,
  saveMemory,
  buildContext,
  logMessage,
} from "./memory.js";
import { createMemoryDb } from "./db.js";
import { createJobs } from "./jobs.js";
import { deliverReply, renderAliveness } from "./aliveness.js";

validateConfig();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel],
  makeCache: Options.cacheWithLimits({
    MessageManager: 25,
    UserManager: 50,
    GuildMemberManager: 50,
  }),
  sweepers: {
    messages: { interval: 300, lifetime: 1800 },
  },
});

const storedMemory = loadMemory();
const conversations = storedMemory.conversations;
const channelFacts = storedMemory.facts;
const spontaneousReplies = new Map();
const memoryDb = createMemoryDb(config.dbPath);
const jobs = createJobs(memoryDb);
let pendingByChannel = new Map();
const lastSpokeAtRef = { value: Date.now() };

setInterval(() => {
  console.log(`RSS: ${process.memoryUsage().rss} bytes`);
  jobs.decay();
}, 10 * 60_000).unref();

function persistMemory() {
  saveMemory(conversations, channelFacts);
}

function updateAffinity(userId) {
  memoryDb.prepare(`
    INSERT INTO relationships(user_id, affinity) VALUES (?, 0.05)
    ON CONFLICT(user_id) DO UPDATE SET affinity = affinity + 0.05
  `).run(userId);
}

function randomDelay(minMinutes, maxMinutes) {
  return (minMinutes + Math.random() * (maxMinutes - minMinutes)) * 60_000;
}

function rememberBotMessage(channelId, answer) {
  const history = conversations.get(channelId) || [];
  conversations.set(channelId, addHistory(history, { role: "assistant", content: answer }));
  persistMemory();
}

function rememberUserMessage(channelId, displayName, content) {
  const history = conversations.get(channelId) || [];
  const entry = { role: "user", content: `${displayName}: ${content}` };
  conversations.set(channelId, addHistory(history, entry));
  persistMemory();
}

function factsContext(channelId) {
  const facts = channelFacts.get(channelId) || [];
  return facts.length ? `Things explicitly remembered in this channel:\n${facts.map((fact) => `- ${fact}`).join("\n")}` : "";
}

async function sendSpontaneousMessage(channel) {
  const lastReply = spontaneousReplies.get(channel.id) || 0;
  if (Date.now() - lastReply < config.spontaneousCooldownMs) return;

  const answer = await askAI({
    prompt: "Start a brief, natural conversation in this Discord channel. Say one short thing, react to the general mood, or ask a light question. Do not mention commands or that you are a bot.",
    personality: config.personality,
    systemContext: renderAliveness(new Date(), lastSpokeAtRef.value),
  });
  await deliverReply({ channel, react: async () => {} }, answer, {
    lastSpokeAtRef,
    spontaneous: true,
  });
  spontaneousReplies.set(channel.id, Date.now());
  rememberBotMessage(channel.id, answer);
}

function scheduleSpontaneousMessages() {
  const channels = client.channels.cache.filter((channel) =>
    channel.isTextBased() && !channel.isDMBased?.() &&
    channel.permissionsFor(client.user)?.has("SendMessages"));

  const available = [...channels.values()];
  if (available.length) {
    const channel = available[Math.floor(Math.random() * available.length)];
    sendSpontaneousMessage(channel).catch((error) =>
      console.error("Spontaneous chat failed:", error));
  }
  setTimeout(scheduleSpontaneousMessages, randomDelay(20, 50));
}

client.once(Events.ClientReady, (readyClient) => {
  console.log(`Logged in as ${readyClient.user.tag}`);
  console.log(`Prefix: ${config.prefix} | Model: ${config.aiModel}`);
  readyClient.application.commands.set([
    { name: "memory_stats", description: "Show persistent memory statistics" },
    { name: "memories", description: "Show remembered facts for a user", options: [{ name: "user", description: "Member to inspect", type: 6, required: true }] },
    { name: "forget_all", description: "Forget a user's facts", options: [{ name: "user", description: "Member to forget", type: 6, required: true }] },
    { name: "reflect_now", description: "Run a self-reflection immediately" },
  ]).catch((error) => console.error("Failed to register memory commands:", error));
  scheduleSpontaneousMessages();
  setInterval(() => jobs.backgroundQueue.add(() => jobs.reflect()), 7 * 24 * 60 * 60_000).unref();
  setInterval(() => jobs.backgroundQueue.add(() => jobs.decay()), 24 * 60 * 60_000).unref();
});

function isAdmin(interaction) {
  return config.adminUserIds.has(interaction.user.id);
}

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand() || !isAdmin(interaction)) return;
  if (!["memory_stats", "memories", "forget_all", "reflect_now"].includes(interaction.commandName)) return;
  await interaction.deferReply({ ephemeral: true });
  if (interaction.commandName === "memory_stats") {
    const messages = memoryDb.prepare("SELECT COUNT(*) AS count FROM messages").get().count;
    const facts = memoryDb.prepare("SELECT COUNT(*) AS count FROM facts").get().count;
    const last = memoryDb.prepare("SELECT MAX(created_at) AS value FROM summaries").get().value;
    const model = memoryDb.prepare("SELECT updated_at FROM self_model WHERE id = 1").get();
    await interaction.editReply(`Messages: ${messages}\nFacts: ${facts}\nLast consolidation: ${last ? new Date(last).toISOString() : "never"}\nSelf-model age: ${Math.round((Date.now() - model.updated_at) / 36e5)} hours`);
  } else if (interaction.commandName === "memories") {
    const user = interaction.options.getUser("user");
    const rows = memoryDb.prepare(`
      SELECT fact FROM facts WHERE subject = ? ORDER BY hits DESC, last_seen DESC LIMIT 20
    `).all(`user:${user.username}`);
    await interaction.editReply(rows.length ? rows.map(({ fact }) => `- ${fact}`).join("\n") : "No memories for that user.");
  } else if (interaction.commandName === "forget_all") {
    const user = interaction.options.getUser("user");
    memoryDb.prepare("DELETE FROM facts WHERE subject = ?").run(`user:${user.username}`);
    await interaction.editReply(`Forgot facts for ${user.username}.`);
  } else {
    await jobs.backgroundQueue.add(() => jobs.reflect());
    await interaction.editReply("Self-reflection completed.");
  }
});

client.on(Events.MessageCreate, async (message) => {
  const loggedId = logMessage(memoryDb, {
    channelId: message.channel.id,
    authorId: message.author.id,
    authorName: message.member?.displayName || message.author.username,
    content: message.content,
    createdAt: message.createdTimestamp,
  });
  jobs.enqueueEmbedding(loggedId, message.content);
  const pending = (pendingByChannel.get(message.channel.id) || 0) + 1;
  pendingByChannel.set(message.channel.id, pending);
  if (pending >= 100) {
    pendingByChannel.set(message.channel.id, 0);
    jobs.backgroundQueue.add(() => jobs.consolidate(message.channel.id));
  }
  if (message.author.bot) return;

  rememberUserMessage(message.channel.id, message.member?.displayName || message.author.username, message.content);

  const mentioned = message.mentions.has(client.user);
  const command = parseCommand(message.content, config.prefix);
  if (!mentioned && command === null) {
    const lastReply = spontaneousReplies.get(message.channel.id) || 0;
    const canReply = Date.now() - lastReply >= config.spontaneousCooldownMs;
    if (!canReply || message.content.length < 8 || Math.random() >= config.spontaneousChance) return;

    await message.channel.sendTyping();
    try {
      const answer = await askAI({
        prompt: `Someone in Discord said: "${message.content}". React naturally, only if there is a reason to join in. If you would add nothing useful, answer exactly: NO_REPLY.`,
        personality: config.personality,
        systemContext: renderAliveness(new Date(), lastSpokeAtRef.value),
      });
      if (!/^no[_\s-]?reply$/i.test(answer.trim())) {
        await deliverReply(message, answer, { lastSpokeAtRef });
        updateAffinity(message.author.id);
        spontaneousReplies.set(message.channel.id, Date.now());
        rememberBotMessage(message.channel.id, answer);
      }
    } catch (error) {
      console.error("Unprompted reply failed:", error);
    }
    return;
  }

  const prompt = command ?? message.content.replaceAll(`<@${client.user.id}>`, "")
    .replaceAll(`<@!${client.user.id}>`, "").trim();
  if (!prompt) {
    await message.reply("Hey! What do you want to talk about?");
    return;
  }

  await message.channel.sendTyping();
  try {
    let answer;
    const rememberedFact = !command ? parseRememberCommand(prompt) : null;
    if (rememberedFact) {
      const facts = channelFacts.get(message.channel.id) || [];
      channelFacts.set(message.channel.id, addFact(facts, rememberedFact));
      persistMemory();
      answer = `Got it, I'll remember this in this channel: ${rememberedFact}`;
    } else if (!command && /^(forget everything|clear memory)$/i.test(prompt)) {
      conversations.delete(message.channel.id);
      channelFacts.delete(message.channel.id);
      persistMemory();
      answer = "Channel memory cleared.";
    } else {
      if (command !== null) {
        const results = await searchWeb(prompt);
        const context = results.length
          ? `Use these current search results as supporting information. Include a source link when useful:\n${results
            .map((result, index) => `${index + 1}. ${result.title}\n${result.snippet}\n${result.url}`)
            .join("\n\n")}`
          : "No useful search result was found. Answer from reliable general knowledge and be clear that the web search returned no match.";
        answer = await askAI({
          prompt,
          personality: config.personality,
          systemContext: `${renderAliveness(new Date(), lastSpokeAtRef.value)}\n${context}`,
        });
      } else {
        const historyKey = message.channel.id;
        const history = conversations.get(historyKey) || [];
        const factsContextText = factsContext(historyKey);
        const persistentContext = buildContext(memoryDb, {
          message: {
            channelId: message.channel.id,
            authorId: message.author.id,
            authorName: message.member?.displayName || message.author.username,
            content: prompt,
          },
          personalityPath: config.personalityPath,
        });
        answer = await askAI({
          prompt,
          personality: config.personality,
          systemContext: `${renderAliveness(new Date(), lastSpokeAtRef.value)}\n${factsContextText}\n${persistentContext.memoryBlock}`,
          conversation: history.slice(0, -1).slice(-HISTORY_LIMIT),
        });
      }
    }
    await deliverReply(message, answer, { lastSpokeAtRef });
    updateAffinity(message.author.id);
    rememberBotMessage(message.channel.id, answer);
  } catch (error) {
    console.error(error);
    await message.reply("My brain tripped for a second. Please try again.");
  }
});

client.login(config.discordToken);
